files = dir('dataFiles/*.txt')
Kmax= 20;
Lcol=[];
for i=1:size(files,1)
    data = load(strcat('dataFiles/',files(i).name))
    [HFD,L] = Higuchi_FD(data, Kmax) ;
    Lcol = [Lcol; L];
end
writematrix(Lcol,'L_Collection.csv') 


